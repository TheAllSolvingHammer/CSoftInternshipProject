//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by UIView.rc
//
#define IDR_USERS_CONTEXT               1000
#define IDR_PROJECTS_CONTEXT            1001
#define IDR_MENU_CONTEXT                1001
#define ID_MENU_INSERT_USER             32773
#define ID_MENU_DELETE_USER             32774
#define ID_MENU_INSERT                  32775
#define ID_MENU_UPDATE                  32776
#define ID_MENU_DELETE                  32777

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        1002
#define _APS_NEXT_COMMAND_VALUE         32778
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           1000
#endif
#endif
