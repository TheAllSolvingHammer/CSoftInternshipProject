//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by UIDialog.rc
//
#define IDD_DLG_USERS                   9
#define IDC_EDB_USERS_NAME              1003
#define IDC_EDB_USERS_EMAIL             1004
#define IDC_STT_USERS_NAME              1005
#define IDC_STT_USERS_EMAIL             1006
#define IDD_LOGIN_DIALOG                1007
#define IDC_STT_USERS_JOB_TITLE         1008
#define IDC_CMB_USERS_JOB_TITLE         1009
#define IDD_REGISTER_DIALOG             1009
#define IDC_EDB_LOGIN_USERNAME          1010
#define IDC_EDB_LOGIN_PASSWORD          1011
#define IDD_PROJECT_DIALOG              1011
#define IDC_STT_LOGIN_USERNAME          1012
#define IDC_STT_LOGIN_PASSWORD          1013
#define IDD_TASK_DIALOG                 1013
#define IDC_BTN_LOGIN_REGISTER          1014
#define IDC_EDB_REGISTER_USERNAME       1015
#define IDC_EDB_REGISTER_EMAIL          1016
#define IDC_CMB_REGISTER_JOB_TITLE      1017
#define IDC_EDB_REGISTER_PASSWORD       1018
#define IDC_EDB_REGISTER_REPEAT_PASSWORD 1022
#define IDC_STT_REGISTER_USERNAME       1023
#define IDC_STT_REGISTER_EMAIL          1024
#define IDC_STT_REGISTER_JOB_TITLE      1025
#define IDC_STT_REGISTER_PASSWORD       1026
#define IDC_STT_REGISTER_REPEAT_PASSWORD 1027
#define IDC_EDB_PROJECT_NAME            1028
#define IDC_CMB_PROJECT_MANAGER         1030
#define IDC_CMB_PROJECT_STATUS          1031
#define IDC_REC_PROJECT_DESCRIPTION     1032
#define IDC_STT_PROJECT_DURATION        1033
#define IDC_STT_PROJECT_EFFORT          1033
#define IDC_STT_PROJECT_LABEL_EFFORT    1034
#define IDC_STT_PROJECT_STATUS          1035
#define IDC_STT_PROJECT_MANAGER         1036
#define IDC_STT_PROJECT_DESCRIPTION     1037
#define IDC_STT_PROJECT_NAME            1038
#define IDC_LSC_PROJECT_TASKS           1040
#define IDC_STT_PROJECT_TASKS           1041
#define IDC_BTN_PROJECT_ADD_TASK        1042
#define IDC_BTN_PROJECT_TASK_DELETE     1043
#define IDC_EDB_TASK_NAME               1043
#define IDC_EDB_TASK_DESCRIPTION        1044
#define IDC_BTN_PROJECT_TASK_UPDATE     1044
#define IDC_CMB_TASK_ASSIGNEE           1045
#define IDC_CMB_TASK_STATUS             1046
#define IDC_EDB_TASK_EFFORT             1047
#define IDC_STT_TASK_EFFORT_LABEL       1048
#define IDC_STT_TASK_STATUS             1049
#define IDC_STT_TASK_ASSIGNEE           1050
#define IDC_STT_TASK_DESCRIPTION        1051
#define IDC_STT_TASK_NAME               1052

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        1015
#define _APS_NEXT_COMMAND_VALUE         32775
#define _APS_NEXT_CONTROL_VALUE         1054
#define _APS_NEXT_SYMED_VALUE           1000
#endif
#endif
