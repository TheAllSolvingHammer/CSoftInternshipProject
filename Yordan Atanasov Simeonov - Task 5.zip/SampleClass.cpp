#include "pch.h"
#include "SampleClass.h"



/////////////////////////////////////////////////////////////////////////////
// CSampleClass

// Constructor / Destructor
// ----------------

CSampleClass::CSampleClass()
{
}

CSampleClass::~CSampleClass()
{
}


// Methods
// ----------------


// Overrides
// ----------------

