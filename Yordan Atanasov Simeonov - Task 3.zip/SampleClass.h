#pragma once


/////////////////////////////////////////////////////////////////////////////
// CSampleClass

class CSampleClass
{

// Constants
// ----------------


// Constructor / Destructor
// ----------------
public:
	CSampleClass();
	virtual ~CSampleClass();


// Methods
// ----------------


// Overrides
// ----------------


// Members
// ----------------


};